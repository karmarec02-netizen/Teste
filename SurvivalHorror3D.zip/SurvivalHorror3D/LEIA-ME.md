# Survival Horror 3D – Projeto Android

O jogo (Three.js + Tailwind, ~17 mil linhas) fica em `app/src/main/assets/index.html`
e roda dentro de uma WebView nativa: tela cheia, paisagem, áudio liberado e saves (localStorage).

## Opção A – Android Studio
1. Abra a pasta no Android Studio (Hedgehog ou mais novo) e aguarde o Gradle Sync.
2. Build > Build APK(s) (ou Run direto no celular).
3. O APK sai em `app/build/outputs/apk/`.

## Opção B – GitHub Actions (sem instalar nada)
1. Suba esta pasta para um repositório no GitHub.
2. Aba Actions > "Build APK" > Run workflow.
3. Baixe o artefato `SurvivalHorror3D-apk` e instale no celular.

## Observação
O jogo carrega Three.js, Tailwind, FontAwesome e imagens/áudios de CDNs, então precisa de internet.
